===============================
🔐 LOCAL SECURITY PORT SCANNER
===============================

Author: Cyber Recon Dashboard Project
Purpose: Educational & authorized security testing only.

---------------------------------------
📌 WHAT THIS TOOL DOES
---------------------------------------
This scanner checks your LOCAL computer for:

✔ Open network ports
✔ Running services (banner grabbing)
✔ Operating System detection
✔ Known vulnerabilities (CVE lookup)

It helps users understand security risks on their own system.

---------------------------------------
⚠ LEGAL NOTICE
---------------------------------------
DO NOT scan systems you do not own or have permission to test.
Unauthorized scanning may be illegal.

This tool is for learning and personal security testing only.

---------------------------------------
🛠 REQUIREMENTS
---------------------------------------
You need Python 3.9+

Install dependencies:

pip install -r requirements.txt

---------------------------------------
▶ HOW TO RUN
---------------------------------------

Step 1: Open Command Prompt in this folder
Step 2: Run:

python scanner.py

---------------------------------------
🔍 WHAT YOU WILL SEE
---------------------------------------

🟢 OPEN Ports  
🔴 Vulnerabilities (if found)  
💻 Detected Operating System  

---------------------------------------
💡 HOW IT WORKS
---------------------------------------
• Scans ports 1–1024 on your local machine  
• Connects to open ports  
• Attempts to read service banners  
• Searches vulnerability database (NVD)  
• Displays results in colored format  

---------------------------------------
📦 PART OF PROJECT
---------------------------------------
This tool is part of the Cyber Recon Dashboard project
for learning cybersecurity concepts.

---------------------------------------
END
---------------------------------------
