import asyncio
import socket
import requests
import nmap
from colorama import Fore, init

init(autoreset=True)

# ================= CONFIG =================
SCAN_TIMEOUT = 1
MAX_PORT = 1024  # first 1024 ports (safe + fast)
NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"

# ==========================================

print(Fore.CYAN + "\n🔐 LOCAL SECURITY PORT SCANNER\n")


# ---------- Banner Grabber ----------
async def grab_banner(ip, port):
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, port), timeout=SCAN_TIMEOUT
        )
        writer.write(b"\n")
        await writer.drain()
        banner = await asyncio.wait_for(reader.read(1024), timeout=SCAN_TIMEOUT)
        writer.close()
        await writer.wait_closed()
        return banner.decode(errors="ignore").strip()
    except:
        return None


# ---------- CVE Lookup ----------
def lookup_cve(service):
    if not service:
        return None

    try:
        params = {"keywordSearch": service, "resultsPerPage": 2}
        r = requests.get(NVD_API, params=params, timeout=5)
        data = r.json()

        vulns = []
        for item in data.get("vulnerabilities", []):
            cve_id = item["cve"]["id"]
            desc = item["cve"]["descriptions"][0]["value"]
            vulns.append(f"{cve_id}: {desc[:80]}...")

        return vulns if vulns else None
    except:
        return None


# ---------- Port Scanner ----------
async def scan_port(ip, port):
    try:
        conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        conn.settimeout(SCAN_TIMEOUT)
        result = conn.connect_ex((ip, port))

        if result == 0:
            banner = await grab_banner(ip, port)
            service = banner if banner else "Unknown Service"
            vulns = lookup_cve(service)

            print(Fore.GREEN + f"🟢 Port {port} OPEN | {service}")

            if vulns:
                print(Fore.RED + "   ⚠ Vulnerabilities:")
                for v in vulns:
                    print(Fore.RED + f"     - {v}")

        conn.close()
    except:
        pass


# ---------- OS Detection ----------
def detect_os(ip):
    nm = nmap.PortScanner()
    nm.scan(ip, arguments='-O')
    try:
        return nm[ip]['osmatch'][0]['name']
    except:
        return "Unknown"


# ---------- Main ----------
async def main():
    target = "127.0.0.1"

    print(Fore.YELLOW + f"Scanning local machine: {target}")
    os_name = detect_os(target)
    print(Fore.MAGENTA + f"Detected OS: {os_name}\n")

    tasks = [scan_port(target, port) for port in range(1, MAX_PORT)]
    await asyncio.gather(*tasks)

    print(Fore.CYAN + "\n✅ Scan Complete!")


if __name__ == "__main__":
    asyncio.run(main())
